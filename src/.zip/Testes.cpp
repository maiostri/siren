#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include "MetricTreeManager.h"
#include "DataDictionaryAccess.h"
#include "Parser.h"
#include "src/utils/logUtils.h"
#include <artemis/image/jpg/JpgLib.hpp>

using namespace std;
using namespace Connections;

int main()
{
    
    vector<string> commandlist;
    string username = "user1";
    string password = "caxias";

    MetricTreeManager *mtm = new MetricTreeManager();

    eConnections eConnectionsEnum = ORACLE;


    ifstream myReadFile;
    myReadFile.open("script.txt");
    string command;
    while (!myReadFile.eof())
    {
        getline(myReadFile, command);
        cout << "Comando a ser executado: " + command << endl;
        Parser *parser = new Parser(eConnectionsEnum, command, username, password, mtm);
        parser->Parse();
        delete parser;
    }
    myReadFile.close();
    delete mtm;


}
